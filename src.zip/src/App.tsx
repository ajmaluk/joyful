import { BrowserRouter, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Suspense, lazy, useCallback, useEffect, useRef, type ReactNode } from 'react';
import { TopBar } from '@/components/layout/TopBar';
import { LeftSidebar } from '@/components/layout/LeftSidebar';
import { ToastContainer } from '@/components/ui/Toast';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { useProjects } from '@/hooks/useProjects';
import { useToast } from '@/hooks/useToast';
import { AnimatePresence, motion } from 'framer-motion';
import type { ChatAttachment, ChatMode, UserSettings } from '@/types';
import * as storage from '@/services/storage';
import { storageManager } from '@/engine/storage';
import { marketingPaths } from '@/components/marketing/marketingRoutes';
import { AuthProvider } from '@/hooks/AuthProvider';
import { useAuth } from '@/hooks/useAuth';
import { consumePendingPromptFull, savePendingPrompt } from '@/services/pendingPrompt';

const LandingPage = lazy(() => import('@/pages/LandingPage').then(module => ({ default: module.LandingPage })));
const BuilderPage = lazy(() => import('@/pages/BuilderPage').then(module => ({ default: module.BuilderPage })));
const DashboardPage = lazy(() => import('@/pages/DashboardPage').then(module => ({ default: module.DashboardPage })));
const TemplatesPage = lazy(() => import('@/pages/TemplatesPage').then(module => ({ default: module.TemplatesPage })));
const SettingsPage = lazy(() => import('@/pages/SettingsPage').then(module => ({ default: module.SettingsPage })));
const DocsPage = lazy(() => import('@/pages/DocsPage').then(module => ({ default: module.DocsPage })));
const PricingPage = lazy(() => import('@/pages/PricingPage').then(module => ({ default: module.PricingPage })));
const LoginPage = lazy(() => import('@/pages/LoginPage').then(module => ({ default: module.LoginPage })));
const SignupPage = lazy(() => import('@/pages/SignupPage').then(module => ({ default: module.SignupPage })));
const NotFoundPage = lazy(() => import('@/pages/NotFoundPage').then(module => ({ default: module.NotFoundPage })));
const SitePage = lazy(() => import('@/pages/SitePage').then(module => ({ default: module.SitePage })));
const BlogListPage = lazy(() => import('@/pages/BlogListPage').then(module => ({ default: module.BlogListPage })));
const BlogPostPage = lazy(() => import('@/pages/BlogPostPage').then(module => ({ default: module.BlogPostPage })));

function RouteLoadingState() {
  return (
    <div className="flex h-full items-center justify-center bg-background text-sm font-medium text-muted-foreground">
      Loading route...
    </div>
  );
}

function AuthGate({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthed, isAuthReady } = useAuth();
  const didRedirectRef = useRef(false);

  useEffect(() => {
    if (!isAuthReady || isAuthed || didRedirectRef.current) return;

    didRedirectRef.current = true;
    navigate('/login', { replace: true, state: { from: location.pathname } });
  }, [isAuthed, isAuthReady, location.pathname, navigate]);

  if (!isAuthReady) {
    return (
      <div className="flex h-full items-center justify-center bg-background text-sm font-medium text-muted-foreground">
        Loading Joyful...
      </div>
    );
  }

  if (!isAuthed) {
    return (
      <div className="flex h-full items-center justify-center bg-background text-sm font-medium text-muted-foreground">
        Redirecting to login...
      </div>
    );
  }

  return children;
}

function AppLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { projects, createProject, updateProject, removeProject } = useProjects();
  const { toasts, addToast, removeToast } = useToast();
  const { isAuthed, isAuthReady } = useAuth();

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = (theme: UserSettings['theme']) => {
      const shouldUseDark = theme === 'dark' || (theme === 'system' && mediaQuery.matches);
      document.documentElement.classList.toggle('dark', shouldUseDark);
      document.documentElement.style.colorScheme = shouldUseDark ? 'dark' : 'light';
    };

    const syncTheme = () => applyTheme(storage.getSettings().theme);
    const handleSettingsChanged = (event: Event) => {
      applyTheme((event as CustomEvent<UserSettings>).detail.theme);
    };

    syncTheme();
    window.addEventListener('joyful_settings_changed', handleSettingsChanged);
    mediaQuery.addEventListener('change', syncTheme);

    return () => {
      window.removeEventListener('joyful_settings_changed', handleSettingsChanged);
      mediaQuery.removeEventListener('change', syncTheme);
    };
  }, []);

  // Initialize IndexedDB-backed StorageManager and wire its events to window events
  useEffect(() => {
    storageManager.init().catch((err) => {
      console.warn('[Storage] Init failed, falling back to localStorage:', err);
    });

    const handleSettingsChanged = (settings: unknown) => {
      window.dispatchEvent(new CustomEvent('joyful_settings_changed', { detail: settings }));
    };
    const handleAuthChanged = () => {
      window.dispatchEvent(new CustomEvent('joyful_auth_changed'));
    };

    storageManager.on('settings_changed', handleSettingsChanged);
    storageManager.on('auth_changed', handleAuthChanged);
    return () => {
      storageManager.off('settings_changed', handleSettingsChanged);
      storageManager.off('auth_changed', handleAuthChanged);
    };
  }, []);

  // Cross-tab synchronization
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key?.startsWith('joyful_projects') || e.key?.startsWith('joyful_settings') || e.key?.startsWith('joyful_chat_')) {
        window.dispatchEvent(new CustomEvent('joyful_crosstab_sync', { detail: { key: e.key } }));
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Pages without sidebar/topbar
  const isAuthPage = location.pathname === '/login' || location.pathname === '/signup';
  const isMarketingPage = marketingPaths.has(location.pathname) || location.pathname.startsWith('/blog/');

  // Show sidebar on all pages except auth and marketing surfaces
  const showSidebar = !isAuthPage && !isMarketingPage;
  const showTopBar = isMarketingPage && location.pathname !== '/docs';

  const handleCreateProject = (name: string, description: string) => {
    const project = createProject(name, description);
    addToast('success', `Created project "${name}"`);
    return project;
  };

  const handleStartProject = useCallback((prompt: string, mode: ChatMode = 'build', attachments: ChatAttachment[] = []) => {
    const trimmedPrompt = prompt.trim();

    if (!isAuthed) {
      savePendingPrompt(trimmedPrompt, mode, attachments.length > 0 ? attachments : undefined);
      addToast('info', 'Log in to start building. Your prompt is saved.');
      navigate('/login', { state: { from: '/builder' } });
      return;
    }

    if (!trimmedPrompt) {
      const emptyProject = [...projects]
        .filter((project) => {
          const hasNoChat = storage.getChatHistory(project.id).length === 0;
          const isLegacyEmpty = project.files.length === 0;
          const isFreshStarter = project.description === 'Fresh blank project';
          return project.status === 'draft' && hasNoChat && (isLegacyEmpty || isFreshStarter);
        })
        .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())[0];

      if (emptyProject) {
        navigate(`/builder/${emptyProject.id}`);
        return;
      }

      const project = createProject('Untitled project', 'Fresh blank project');
      navigate(`/builder/${project.id}`);
      addToast('success', 'Opened a fresh project');
      return;
    }

    const cleanName = trimmedPrompt
      .replace(/\s+/g, ' ')
      .slice(0, 54)
      .replace(/[.,;:!?-]+$/g, '')
      .trim();
    const project = createProject(cleanName || 'New Joyful project', trimmedPrompt);
    navigate(`/builder/${project.id}`, { state: { initialPrompt: trimmedPrompt, initialMode: mode, initialAttachments: attachments } });
    addToast('success', `Created project "${project.name}"`);
  }, [addToast, createProject, isAuthed, navigate, projects]);

  useEffect(() => {
    if (!isAuthReady || !isAuthed || !isAuthPage) return;

    const pendingData = consumePendingPromptFull();
    if (pendingData !== null) {
      handleStartProject(pendingData.prompt, pendingData.mode, pendingData.attachments || []);
      return;
    }

    const from = (location.state as { from?: string } | null)?.from;
    navigate(from && from !== '/login' && from !== '/signup' ? from : '/builder', { replace: true });
  }, [handleStartProject, isAuthPage, isAuthReady, isAuthed, location.state, navigate]);

  return (
    <div className="h-screen overflow-hidden bg-[linear-gradient(180deg,#ffffff_0%,#e8ecff_20%,#d4dcff_38%,#f0e0ff_56%,#ffe0ec_72%,#fff0e0_100%)] dark:bg-[linear-gradient(180deg,#0a0a0a_0%,#161719_20%,#21365f_38%,#3a2040_56%,#4a1030_72%,#4a2010_100%)] text-foreground">
      {showTopBar && <TopBar />}

      <div className="flex h-full min-h-0">
        {showSidebar && (
          <LeftSidebar projects={projects} onNewProject={() => handleStartProject('')} />
        )}

        <main className={`min-w-0 flex-1 ${isMarketingPage ? 'overflow-y-auto' : 'overflow-hidden'}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-full min-h-0"
            >
              <Suspense fallback={<RouteLoadingState />}>
                <Routes location={location}>
                  <Route path="/" element={isAuthed ? <Navigate to="/builder" replace /> : <LandingPage onStartProject={handleStartProject} />} />
                  <Route
                    path="/dashboard"
                    element={<Navigate to="/builder" replace />}
                  />
                  <Route
                    path="/builder"
                    element={
                      <ErrorBoundary>
                        <AuthGate>
                          <DashboardPage
                            projects={projects}
                            onCreateProject={handleCreateProject}
                            onDeleteProject={removeProject}
                            onStartProject={handleStartProject}
                          />
                        </AuthGate>
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/builder/:projectId"
                    element={
                      <ErrorBoundary>
                        <AuthGate>
                          <BuilderPage
                            projects={projects}
                            onUpdateProject={updateProject}
                          />
                        </AuthGate>
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/templates"
                    element={
                      <ErrorBoundary>
                        <AuthGate>
                          <TemplatesPage onCreateProject={handleCreateProject} onUpdateProject={updateProject} />
                        </AuthGate>
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/settings"
                    element={
                      <ErrorBoundary>
                        <AuthGate>
                          <SettingsPage />
                        </AuthGate>
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/docs"
                    element={
                      <ErrorBoundary>
                        <DocsPage />
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/pricing"
                    element={
                      <ErrorBoundary>
                        <PricingPage />
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/login"
                    element={
                      <ErrorBoundary>
                        <LoginPage />
                      </ErrorBoundary>
                    }
                  />
                  <Route
                    path="/signup"
                    element={
                      <ErrorBoundary>
                        <SignupPage />
                      </ErrorBoundary>
                    }
                  />
                  <Route path="/blog" element={<ErrorBoundary><BlogListPage onStartProject={handleStartProject} /></ErrorBoundary>} />
                  <Route path="/blog/:slug" element={<ErrorBoundary><BlogPostPage onStartProject={handleStartProject} /></ErrorBoundary>} />
                  <Route path="/guides" element={<SitePage slug="guides" onStartProject={handleStartProject} />} />
                  <Route path="/examples" element={<SitePage slug="examples" onStartProject={handleStartProject} />} />
                  <Route path="/support" element={<SitePage slug="support" onStartProject={handleStartProject} />} />
                  <Route path="/about" element={<SitePage slug="about" onStartProject={handleStartProject} />} />
                  <Route path="/security" element={<SitePage slug="security" onStartProject={handleStartProject} />} />
                  <Route path="/contact" element={<SitePage slug="contact" onStartProject={handleStartProject} />} />
                  <Route path="/status" element={<SitePage slug="status" onStartProject={handleStartProject} />} />
                  <Route path="/privacy" element={<SitePage slug="privacy" onStartProject={handleStartProject} />} />
                  <Route path="/terms" element={<SitePage slug="terms" onStartProject={handleStartProject} />} />
                  <Route path="/cookies" element={<SitePage slug="cookies" onStartProject={handleStartProject} />} />
                  <Route path="/licenses" element={<SitePage slug="licenses" onStartProject={handleStartProject} />} />
                  <Route path="*" element={<NotFoundPage />} />
                </Routes>
              </Suspense>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Toast notifications */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppLayout />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
